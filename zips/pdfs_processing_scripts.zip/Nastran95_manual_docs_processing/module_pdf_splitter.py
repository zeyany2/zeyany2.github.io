import os
from PyPDF2 import PdfReader, PdfWriter
from pathlib import Path

def split_pdf(input_path, output_directory, pages_per_file=10, name_prefix='split'):
    """
    Split a PDF file into smaller PDFs with specified number of pages per file.
    
    Args:
        input_path (str): Path to the input PDF file
        output_directory (str): Directory where split PDFs will be saved
        pages_per_file (int): Number of pages per output PDF file
    """
    try:
        # Create output directory if it doesn't exist
        Path(output_directory).mkdir(parents=True, exist_ok=True)
        
        # Read the PDF file
        reader = PdfReader(input_path)
        total_pages = len(reader.pages)
        
        # Calculate number of output files needed
        num_files = (total_pages + pages_per_file - 1) // pages_per_file
        
        print(f"Total pages: {total_pages}")
        print(f"Will create {num_files} output files")
        
        for i in range(num_files):
            # Create a PDF writer object
            writer = PdfWriter()
            
            # Calculate start and end pages for this chunk
            start_page = i * pages_per_file
            end_page = min((i + 1) * pages_per_file, total_pages)
            
            # Add pages to writer
            for page_num in range(start_page, end_page):
                writer.add_page(reader.pages[page_num])
            
            # Generate output filename
            output_filename = f"{name_prefix}_{i + 1:03d}.pdf"
            output_path = os.path.join(output_directory, output_filename)
            
            # Save the split PDF
            with open(output_path, 'wb') as output_file:
                writer.write(output_file)
            
            print(f"Created: {output_filename} (Pages {start_page + 1}-{end_page})")
            
        print("\nPDF splitting completed successfully!")
    except FileNotFoundError:
        print(f"Error: Input file '{input_path}' not found!")
    except PermissionError:
        print(f"Error: Permission denied when accessing files!")
    except Exception as e:
        print(f"An unexpected error occurred: {str(e)}")

# Example usage
if __name__ == "__main__":
    # Replace these values with your actual paths
    input_pdf = "large_file.pdf"
    output_dir = "split_pdfs"
    pages_per_chunk = 10
    name_prefix = 'split'
    
    split_pdf(input_pdf, output_dir, pages_per_chunk, name_prefix)