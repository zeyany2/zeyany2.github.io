from module_pdf_splitter import split_pdf
from module_pdf2txt import process_all_pdf_in_dir



def main():
    pdf_file = 'NASTRAN Users Manual 2.pdf'
    output_folder = 'user'
    num_pages = 20
    name_prefix = 'users_manual'
    split_pdf(pdf_file, output_folder, num_pages, name_prefix)


    doc_title = "User's Manual"

    process_all_pdf_in_dir(output_folder, doc_title)



if __name__ == "__main__":
    main()

