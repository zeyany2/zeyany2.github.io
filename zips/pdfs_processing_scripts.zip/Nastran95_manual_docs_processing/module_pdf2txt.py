import PyPDF2
import os

def pdf_to_text(pdf_path, txt_path, header_text=""):
    # Open the PDF file
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        
        # Extract text from each page
        text = header_text + "\n\n"  # Add header text at the beginning
        for page in reader.pages:
            text += page.extract_text() + "\n\n"
        
        # Write to text file
        with open(txt_path, 'w', encoding='utf-8') as txt_file:
            txt_file.write(text)


def process_all_pdf_in_dir(pdf_dir, doc_title="Document"):
    # Process all PDF files in the given directory
    pdf_files = sorted([f for f in os.listdir(pdf_dir) if f.endswith('.pdf')])
    
    for index, pdf_file in enumerate(pdf_files, start=1):
        pdf_path = os.path.join(pdf_dir, pdf_file)
        txt_file = os.path.splitext(pdf_file)[0] + '.md'
        txt_path = os.path.join(pdf_dir, txt_file)
        
        header_text = f"""---
title: {doc_title} P{index}
type: docs
---

"""
        pdf_to_text(pdf_path, txt_path, header_text)
        print(f"Converted {pdf_file} to {txt_file}")

    print("All PDF files have been converted to text files.")
